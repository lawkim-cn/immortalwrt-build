# Changelog

## [1.20.1](https://github.com/daeuniverse/daed/compare/dae-editor-v1.20.0...dae-editor-v1.20.1) (2026-04-17)


### Bug Fixes

* **security:** mitigate polynomial ReDoS in formatter and parser ([589b5d2](https://github.com/daeuniverse/daed/commit/589b5d2fcc1d5745be390fbdc2602e11e6c964c6))

## [1.20.0](https://github.com/daeuniverse/daed/compare/dae-editor-v1.19.1...dae-editor-v1.20.0) (2026-03-31)


### Features

* add RoutingA language formatter and integrate with Monaco editor ([8b40e9b](https://github.com/daeuniverse/daed/commit/8b40e9b4f8a76f83033f99a9ed58779c00381643))
* **dae-lsp:** add browser LSP support and fix completions ([32b5b49](https://github.com/daeuniverse/daed/commit/32b5b49abd58b8f16c72a2f2dd188bc7c2cf7877))
* re-trigger release-please ([4febcf7](https://github.com/daeuniverse/daed/commit/4febcf7ebba807474e8215510669e0a756c31585))
* split dae-editor and dae-node-parser into its own package ([08d7d80](https://github.com/daeuniverse/daed/commit/08d7d805f21eca5abc16b2f61111e374d2413c0b))
* trigger release ([e6618d5](https://github.com/daeuniverse/daed/commit/e6618d5cfb721dec3633278018e2f254c23daff9))
* update pnpm workspace and add turbo configuration ([4484dc4](https://github.com/daeuniverse/daed/commit/4484dc43be6f1d229053bcc7bd589c528707024f))


### Bug Fixes

* 节点行域名过长时删除按钮被挤出可视区域 ([55030d3](https://github.com/daeuniverse/daed/commit/55030d340da11a0e55cb8bb95caf314b42c23386))

## [1.19.1](https://github.com/daeuniverse/daed/compare/dae-editor-v1.19.0...dae-editor-v1.19.1) (2026-02-28)


### Bug Fixes

* 节点行域名过长时删除按钮被挤出可视区域 ([55030d3](https://github.com/daeuniverse/daed/commit/55030d340da11a0e55cb8bb95caf314b42c23386))

## [1.19.0](https://github.com/daeuniverse/daed/compare/dae-editor-v1.18.0...dae-editor-v1.19.0) (2025-12-07)


### Features

* **dae-lsp:** add browser LSP support and fix completions ([32b5b49](https://github.com/daeuniverse/daed/commit/32b5b49abd58b8f16c72a2f2dd188bc7c2cf7877))

## [1.18.0](https://github.com/daeuniverse/daed/compare/dae-editor-v1.17.0...dae-editor-v1.18.0) (2025-12-06)


### Features

* trigger release ([e6618d5](https://github.com/daeuniverse/daed/commit/e6618d5cfb721dec3633278018e2f254c23daff9))

## [1.17.0](https://github.com/daeuniverse/daed/compare/dae-editor-v1.16.0...dae-editor-v1.17.0) (2025-12-04)


### Features

* update pnpm workspace and add turbo configuration ([4484dc4](https://github.com/daeuniverse/daed/commit/4484dc43be6f1d229053bcc7bd589c528707024f))

## [1.16.0](https://github.com/daeuniverse/daed/compare/dae-editor-v1.15.0...dae-editor-v1.16.0) (2025-12-03)


### Features

* add RoutingA language formatter and integrate with Monaco editor ([8b40e9b](https://github.com/daeuniverse/daed/commit/8b40e9b4f8a76f83033f99a9ed58779c00381643))

## [1.15.0](https://github.com/daeuniverse/daed/compare/dae-editor-v1.14.0...dae-editor-v1.15.0) (2025-12-03)


### Features

* re-trigger release-please ([4febcf7](https://github.com/daeuniverse/daed/commit/4febcf7ebba807474e8215510669e0a756c31585))

## [1.14.0](https://github.com/daeuniverse/daed/compare/dae-editor-v1.13.1...dae-editor-v1.14.0) (2025-12-03)


### Features

* re-trigger release-please ([4febcf7](https://github.com/daeuniverse/daed/commit/4febcf7ebba807474e8215510669e0a756c31585))

## [1.12.0](https://github.com/daeuniverse/daed/compare/dae-editor-v1.11.0...dae-editor-v1.12.0) (2025-12-03)


### Features

* split dae-editor and dae-node-parser into its own package ([08d7d80](https://github.com/daeuniverse/daed/commit/08d7d805f21eca5abc16b2f61111e374d2413c0b))
