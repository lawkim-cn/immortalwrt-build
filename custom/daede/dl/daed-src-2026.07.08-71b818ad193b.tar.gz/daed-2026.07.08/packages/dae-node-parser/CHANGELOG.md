# Changelog

## [1.21.0](https://github.com/daeuniverse/daed/compare/dae-node-parser-v1.20.1...dae-node-parser-v1.21.0) (2026-03-31)


### Features

* **dae-lsp:** add browser LSP support and fix completions ([32b5b49](https://github.com/daeuniverse/daed/commit/32b5b49abd58b8f16c72a2f2dd188bc7c2cf7877))
* enhance V2Ray URL parsing and configuration options ([3829c0f](https://github.com/daeuniverse/daed/commit/3829c0f402fea80b74fc1263220de4276699b1a1))
* optimize user experience ([7013499](https://github.com/daeuniverse/daed/commit/701349900e004eafa8c3e4c4326059c63fb8057a))
* re-trigger release-please ([4febcf7](https://github.com/daeuniverse/daed/commit/4febcf7ebba807474e8215510669e0a756c31585))
* split dae-editor and dae-node-parser into its own package ([08d7d80](https://github.com/daeuniverse/daed/commit/08d7d805f21eca5abc16b2f61111e374d2413c0b))
* trigger release ([e6618d5](https://github.com/daeuniverse/daed/commit/e6618d5cfb721dec3633278018e2f254c23daff9))
* update pnpm workspace and add turbo configuration ([4484dc4](https://github.com/daeuniverse/daed/commit/4484dc43be6f1d229053bcc7bd589c528707024f))


### Bug Fixes

* 节点行域名过长时删除按钮被挤出可视区域 ([55030d3](https://github.com/daeuniverse/daed/commit/55030d340da11a0e55cb8bb95caf314b42c23386))

## [1.20.1](https://github.com/daeuniverse/daed/compare/dae-node-parser-v1.20.0...dae-node-parser-v1.20.1) (2026-02-28)


### Bug Fixes

* 节点行域名过长时删除按钮被挤出可视区域 ([55030d3](https://github.com/daeuniverse/daed/commit/55030d340da11a0e55cb8bb95caf314b42c23386))

## [1.20.0](https://github.com/daeuniverse/daed/compare/dae-node-parser-v1.19.0...dae-node-parser-v1.20.0) (2026-02-07)


### Features

* optimize user experience ([7013499](https://github.com/daeuniverse/daed/commit/701349900e004eafa8c3e4c4326059c63fb8057a))

## [1.19.0](https://github.com/daeuniverse/daed/compare/dae-node-parser-v1.18.0...dae-node-parser-v1.19.0) (2025-12-07)


### Features

* **dae-lsp:** add browser LSP support and fix completions ([32b5b49](https://github.com/daeuniverse/daed/commit/32b5b49abd58b8f16c72a2f2dd188bc7c2cf7877))

## [1.18.0](https://github.com/daeuniverse/daed/compare/dae-node-parser-v1.17.0...dae-node-parser-v1.18.0) (2025-12-06)


### Features

* trigger release ([e6618d5](https://github.com/daeuniverse/daed/commit/e6618d5cfb721dec3633278018e2f254c23daff9))

## [1.17.0](https://github.com/daeuniverse/daed/compare/dae-node-parser-v1.16.0...dae-node-parser-v1.17.0) (2025-12-04)


### Features

* update pnpm workspace and add turbo configuration ([4484dc4](https://github.com/daeuniverse/daed/commit/4484dc43be6f1d229053bcc7bd589c528707024f))

## [1.16.0](https://github.com/daeuniverse/daed/compare/dae-node-parser-v1.15.0...dae-node-parser-v1.16.0) (2025-12-03)


### Features

* enhance V2Ray URL parsing and configuration options ([3829c0f](https://github.com/daeuniverse/daed/commit/3829c0f402fea80b74fc1263220de4276699b1a1))

## [1.15.0](https://github.com/daeuniverse/daed/compare/dae-node-parser-v1.14.0...dae-node-parser-v1.15.0) (2025-12-03)


### Features

* re-trigger release-please ([4febcf7](https://github.com/daeuniverse/daed/commit/4febcf7ebba807474e8215510669e0a756c31585))

## [1.14.0](https://github.com/daeuniverse/daed/compare/dae-node-parser-v1.13.1...dae-node-parser-v1.14.0) (2025-12-03)


### Features

* re-trigger release-please ([4febcf7](https://github.com/daeuniverse/daed/commit/4febcf7ebba807474e8215510669e0a756c31585))

## [1.12.0](https://github.com/daeuniverse/daed/compare/dae-node-parser-v1.11.0...dae-node-parser-v1.12.0) (2025-12-03)


### Features

* split dae-editor and dae-node-parser into its own package ([08d7d80](https://github.com/daeuniverse/daed/commit/08d7d805f21eca5abc16b2f61111e374d2413c0b))
